package com.example.telegramchecker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF050505)
private val Panel = Color(0xFF101010)
private val Line = Color(0xFF555555)
private val Muted = Color(0xFF9A9A9A)
private val White = Color(0xFFEAEAEA)
private val Green = Color(0xFF73C991)
private val Red = Color(0xFFE07A7A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TelegramCheckerApp() }
    }
}

private enum class SearchMode { USERNAME, PHONE, CHANNEL }

@Composable
fun TelegramCheckerApp() {
    var mode by remember { mutableStateOf(SearchMode.USERNAME) }
    var query by remember { mutableStateOf("") }
    var result by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("أدخل بيانات عامة ثم اضغط فحص") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Panel,
            primary = White,
            onBackground = White,
            onSurface = White
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Bg)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("⋮", color = Muted, fontSize = 28.sp)
                Text("TELEGRAM CHECKER", color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("⌕", color = Muted, fontSize = 25.sp)
            }

            Spacer(Modifier.height(42.dp))

            Text(
                "PUBLIC ACCOUNT LOOKUP",
                color = Muted,
                fontSize = 11.sp,
                letterSpacing = 2.sp
            )
            Spacer(Modifier.height(18.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Line, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                ModeTab("USERNAME", mode == SearchMode.USERNAME) {
                    mode = SearchMode.USERNAME; query = ""; result = false
                }
                ModeTab("PHONE", mode == SearchMode.PHONE) {
                    mode = SearchMode.PHONE; query = ""; result = false
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Line)
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                ModeTab("CHANNEL", mode == SearchMode.CHANNEL) {
                    mode = SearchMode.CHANNEL; query = ""; result = false
                }
            }

            Spacer(Modifier.height(22.dp))

            OutlinedTextField(
                value = query,
                onValueChange = { query = it; result = false },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = {
                    Text(
                        when (mode) {
                            SearchMode.USERNAME -> "Telegram username"
                            SearchMode.PHONE -> "Your permitted contact number"
                            SearchMode.CHANNEL -> "Public channel username"
                        }
                    )
                },
                placeholder = {
                    Text(
                        when (mode) {
                            SearchMode.USERNAME -> "@username"
                            SearchMode.PHONE -> "+20xxxxxxxxxx"
                            SearchMode.CHANNEL -> "@publicchannel"
                        },
                        color = Muted
                    )
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = if (mode == SearchMode.PHONE) KeyboardType.Phone else KeyboardType.Text
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = White,
                    unfocusedBorderColor = Line,
                    focusedLabelColor = White,
                    unfocusedLabelColor = Muted,
                    cursorColor = White
                )
            )

            Spacer(Modifier.height(14.dp))

            Button(
                onClick = {
                    result = true
                    message = when {
                        query.isBlank() -> "اكتب قيمة للبحث أولاً"
                        mode == SearchMode.PHONE ->
                            "البحث بالرقم متاح فقط لجهات الاتصال التي تملك صلاحية الوصول إليها. لا يمكن تأكيد الحظر من الرقم."
                        else ->
                            "واجهة العرض جاهزة. لم يتم الاتصال بخدمة Telegram بعد؛ لا تعتبر هذه النتيجة إثباتًا لحالة الحظر."
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF202020)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.Search, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("CHECK")
            }

            Spacer(Modifier.height(28.dp))

            if (result) {
                ResultCard(mode, query, message)
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(230.dp)
                        .border(1.dp, Line, RoundedCornerShape(28.dp))
                        .background(Panel, RoundedCornerShape(28.dp))
                        .padding(22.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("◉", color = Muted, fontSize = 42.sp)
                        Spacer(Modifier.height(12.dp))
                        Text("RESULT WILL APPEAR HERE", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("نتيجة الفحص ستظهر في هذا المربع", color = White, fontSize = 14.sp)
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            Text(
                "تنبيه: عدم العثور على حساب لا يعني أنه محظور أو متجمّد. التطبيق حاليًا نموذج واجهة ولا يجري فحصًا مباشرًا.",
                color = Muted,
                fontSize = 11.sp,
                lineHeight = 18.sp,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(24.dp))
            Text("TELEGRAM CHECKER • VERSION 1.0", color = Color(0xFF666666), fontSize = 10.sp)
        }
    }
}

@Composable
private fun ModeTab(label: String, selected: Boolean, onClick: () -> Unit) {
    TextButton(onClick = onClick) {
        Text(
            label,
            color = if (selected) White else Muted,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            letterSpacing = 1.sp
        )
    }
}

@Composable
private fun ResultCard(mode: SearchMode, query: String, message: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Line, RoundedCornerShape(28.dp))
            .background(Panel, RoundedCornerShape(28.dp))
            .padding(22.dp)
    ) {
        Text(
            when (mode) {
                SearchMode.USERNAME -> "ACCOUNT RESULT"
                SearchMode.PHONE -> "PHONE LOOKUP"
                SearchMode.CHANNEL -> "CHANNEL RESULT"
            },
            color = Muted,
            fontSize = 11.sp,
            letterSpacing = 2.sp
        )
        Spacer(Modifier.height(18.dp))
        Text(query.ifBlank { "—" }, color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text("STATUS", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
        Text("UNKNOWN / NOT VERIFIED", color = Red, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(message, color = White, fontSize = 13.sp, lineHeight = 20.sp)
        if (mode == SearchMode.CHANNEL) {
            Spacer(Modifier.height(16.dp))
            Text("الصورة وعدد المشتركين سيظهران عند ربط مصدر رسمي يدعم هذه البيانات.", color = Muted, fontSize = 12.sp)
        }
    }
}
